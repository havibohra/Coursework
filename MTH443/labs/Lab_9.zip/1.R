library(MASS)
library(naivebayes)

iris <- read.csv('./iris.csv')

calculateMisclf <- function(model, x, y)
{
  model.pred <- predict(object = model, newdata = x)$class
  model.pred <- as.vector(model.pred)
  misclf <- mean(y != model.pred)
  return(misclf)
}

n.samples <- nrow(iris)
train.indices <- sample(x = 1:n.samples,
                        size = floor(0.9 * n.samples))
train <- iris[train.indices, ]
test <- iris[-c(train.indices), ]

x.train <- subset(train, select = -c(Species_name))
y.train <- train$Species_name

x.test <- subset(test, select = -c(Species_name))
y.test <- test$Species_name

# LDA
lda.model <- lda(Species_name ~ ., data = train, 
                 prior = c(0.33, 0.33, 0.34))

misclf.train.lda <- calculateMisclf(lda.model, x.train, y.train)
misclf.test.lda <- calculateMisclf(lda.model, x.test, y.test)

# QDA
qda.model <- qda(Species_name ~ ., data = train, 
                 prior = c(0.33, 0.33, 0.34))

misclf.train.qda <- calculateMisclf(qda.model, x.train, y.train)
misclf.test.qda <- calculateMisclf(qda.model, x.test, y.test)

# Bayes
bayes.model <- naive_bayes(Species_name ~ ., data = train,
                           usekernel = T)
bayes.train.pred <- as.vector(predict(bayes.model, x.train))
bayes.test.pred <- as.vector(predict(bayes.model, x.test))
misclf.train.bayes <- mean(y.train != bayes.train.pred)
misclf.test.bayes <- mean(y.test != bayes.test.pred)

misclf <- matrix(data = c(misclf.train.lda, misclf.test.lda, 
                          misclf.train.qda, misclf.test.qda,
                          misclf.train.bayes, misclf.test.bayes),
                 byrow = T, ncol = 2)
rownames(misclf) <- c("LDA", "QDA", "Bayes")
colnames(misclf) <- c("Train", "Test")
print(misclf)
