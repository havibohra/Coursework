library(MASS)

data <- read.csv('heart.csv')
n.data <- length(data[ ,1])
n.train <- floor(0.9 * n.data)

train <- data[1:n.train, ]
test <- data[(n.train+1): n.data,]

x.train <- subset(train, select = -c(coronary.hd))
y.train <- train$coronary.hd

x.test <- subset(test, select = -c(coronary.hd))
y.test <- test$coronary.hd

##### LDA Model
lda.model <- lda(coronary.hd ~ ., data = train)
lda.model

prediction.train <- predict(object = lda.model, newdata = x.train)
prediction.test <- predict(object = lda.model, newdata = x.test)

### Misclassificaion prob
misclf.train <- sum(prediction.train$class != y.train) / (n.train)
print(misclf.train)

misclf.test <- sum(prediction.test$class != y.test) / (n.data - n.train)
print(misclf.test)

##### QDA Model
qda.model <- qda(coronary.hd ~ ., data = train)

prediction.train <- predict(object = qda.model, newdata = x.train)
prediction.test <- predict(object = qda.model, newdata = x.test)

### Misclassificaion prob
misclf.train <- sum(prediction.train$class != y.train) / (n.train)
print(misclf.train)

misclf.test <- sum(prediction.test$class != y.test) / (n.data - n.train)
print(misclf.test)