library(MASS)

data <- read.csv('currency_crisis.csv', skip = 1)
data <- subset(data, select = -c(X))

##### Last 10% split
n.data <- length(data[ ,1])
n.train <- floor(0.9 * n.data)

train <- data[1:n.train, ]
test <- data[(n.train+1): n.data,]

x.train <- subset(train, select = -c(Currency.crisis.with.in.next.12.months))
y.train <- train$Currency.crisis.with.in.next.12.months

x.test <- subset(test, select = -c(Currency.crisis.with.in.next.12.months))
y.test <- test$Currency.crisis.with.in.next.12.months

##### LDA Model
lda.model <- lda(Currency.crisis.with.in.next.12.months ~ ., data = train)

prediction.train <- predict(object = lda.model, newdata = x.train)
prediction.test <- predict(object = lda.model, newdata = x.test)

### Misclassificaion prob
misclf.train <- sum(prediction.train$class != y.train) / (n.train)
print(misclf.train)

misclf.test <- sum(prediction.test$class != y.test) / (n.data - n.train)
print(misclf.test)

##### QDA Model
qda.model <- qda(Currency.crisis.with.in.next.12.months ~ ., data = train)

prediction.train <- predict(object = qda.model, newdata = x.train)
prediction.test <- predict(object = qda.model, newdata = x.test)

### Misclassificaion prob
misclf.train <- sum(prediction.train$class != y.train) / (n.train)
print(misclf.train)

misclf.test <- sum(prediction.test$class != y.test) / (n.data - n.train)
print(misclf.test)

# The test data is not representative of the
# population. It contains all 1's, whereas train
# data contains only 27% 1's.











##### 10th observation split
test.rows <- seq(from = 10, to = n.data, by = 10)

train <- data[-c(test.rows), ]
test <- data[test.rows,]

x.train <- subset(train, select = -c(Currency.crisis.with.in.next.12.months))
y.train <- train$Currency.crisis.with.in.next.12.months

x.test <- subset(test, select = -c(Currency.crisis.with.in.next.12.months))
y.test <- test$Currency.crisis.with.in.next.12.months

##### LDA Model
lda.model <- lda(Currency.crisis.with.in.next.12.months ~ ., data = train)
# lda.model

prediction.train <- predict(object = lda.model, newdata = x.train)
prediction.test <- predict(object = lda.model, newdata = x.test)

### Misclassificaion prob
misclf.train <- mean(prediction.train$class != y.train)
print(misclf.train)

misclf.test <- mean(prediction.test$class != y.test)
print(misclf.test)

##### QDA Model
qda.model <- qda(Currency.crisis.with.in.next.12.months ~ ., data = train)

prediction.train <- predict(object = qda.model, newdata = x.train)
prediction.test <- predict(object = qda.model, newdata = x.test)

### Misclassificaion prob
misclf.train <- mean(prediction.train$class != y.train)
print(misclf.train)

misclf.test <- mean(prediction.test$class != y.test)
print(misclf.test)