data <- read.csv('./CHD.csv')
class1.data <- data[(data$TenYearCHD == 1),]
class0.data <- data[(data$TenYearCHD == 0),]

imputeMean <- function(x)
{
  x.mean <- mean(x, na.rm = T)
  x[is.na(x)] <- x.mean
  return(x)
}

class1.data <- as.data.frame(apply(class1.data, MARGIN = 2, FUN = imputeMean))
class0.data <- as.data.frame(apply(class0.data, MARGIN = 2, FUN = imputeMean))

##### A) Density Estimation

### Kernel Density

# Gaussian Kernel
class1.gaussian <- density(x = class1.data$totChol, kernel = 'gaussian')
class0.gaussian <- density(x = class0.data$totChol, kernel = 'gaussian')

hist(x = class1.data$totChol, probability = T, xlab = "Total Cholesterol (Gaussian)",
     main = "Class 1")
lines(class1.gaussian, lwd = 2)
hist(x = class0.data$totChol, probability = T, xlab = "Total Cholesterol (Gaussian)",
     main = "Class 0")
lines(class0.gaussian, lwd = 2)

plot(class0.gaussian, xlab = "Total Cholesterol (Gaussian)", ylab = "Density", 
     col = 1, lwd = 2, main = "Comparison")
lines(class1.gaussian, col = 2, lwd = 2)
legend("topright", legend = c('0', '1'), fill = c(1, 2))

# Rectangular Kernel
class1.rectangular <- density(x = class1.data$totChol, kernel = 'rectangular')
class0.rectangular <- density(x = class0.data$totChol, kernel = 'rectangular')

hist(x = class1.data$totChol, probability = T, xlab = "Total Cholesterol (rectangular)",
     main = "Class 1")
lines(class1.rectangular, lwd = 2)
hist(x = class0.data$totChol, probability = T, xlab = "Total Cholesterol (rectangular)",
     main = "Class 0")
lines(class0.rectangular, lwd = 2)

plot(class0.rectangular, xlab = "Total Cholesterol (rectangular)", ylab = "Density", 
     col = 1, lwd = 2, main = "Comparison")
lines(class1.rectangular, col = 2, lwd = 2)
legend("topright", legend = c('0', '1'), fill = c(1, 2))

# Triangular
class1.triangular <- density(x = class1.data$totChol, kernel = 'triangular')
class0.triangular <- density(x = class0.data$totChol, kernel = 'triangular')

hist(x = class1.data$totChol, probability = T, xlab = "Total Cholesterol (triangular)",
     main = "Class 1")
lines(class1.triangular, lwd = 2)
hist(x = class0.data$totChol, probability = T, xlab = "Total Cholesterol (triangular)",
     main = "Class 0")
lines(class0.triangular, lwd = 2)

plot(class0.triangular, xlab = "Total Cholesterol (triangular)", ylab = "Density", 
     col = 1, lwd = 2, main = "Comparison")
lines(class1.triangular, col = 2, lwd = 2)
legend("topright", legend = c('0', '1'), fill = c(1, 2))

# epanechnikov
class1.epanechnikov <- density(x = class1.data$totChol, kernel = 'epanechnikov')
class0.epanechnikov <- density(x = class0.data$totChol, kernel = 'epanechnikov')

hist(x = class1.data$totChol, probability = T, xlab = "Total Cholesterol (epanechnikov)",
     main = "Class 1")
lines(class1.epanechnikov, lwd = 2)
hist(x = class0.data$totChol, probability = T, xlab = "Total Cholesterol (epanechnikov)",
     main = "Class 0")
lines(class0.epanechnikov, lwd = 2)

plot(class0.epanechnikov, xlab = "Total Cholesterol (epanechnikov)", ylab = "Density", 
     col = 1, lwd = 2, main = "Comparison")
lines(class1.epanechnikov, col = 2, lwd = 2)
legend("topright", legend = c('0', '1'), fill = c(1, 2))

##### B)
# Both the densities have similar mode
# but the density is function is more peaked
# for class 0. Class 1 has thicker tails

##### C)
# Reference: https://stats.stackexchange.com/questions/71072/calculate-tail-probabilities-from-density-call-in-r#:~:text=For%20instance,%20the%20right%20tail%20probability%20at%20the%20value%20x
threshold <- seq(from = 200, to = 500, by = 25)
right.tail.prob <- matrix(data = 0, nrow = length(threshold), ncol = 3)
colnames(right.tail.prob) <- c('Threshold', 'Class 1', 'Class 0')

for(i in 1:length(threshold))
{
  right.tail.prob[i, 1] <- threshold[i]
  class1.density <- density(x = class1.data$totChol, from = threshold[i])
  class0.density <- density(x = class0.data$totChol, from = threshold[i])
  
  right.tail.prob[i, 2] <- with(class1.density, sum(y * diff(x)[1]))
  right.tail.prob[i, 3] <- with(class0.density, sum(y * diff(x)[1]))
}
