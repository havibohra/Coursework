# TCP Handshake Client (Raw Sockets)

## Overview
This project implements a TCP client using *raw sockets* to perform the *TCP three-way handshake. It is part of **Assignment 3* for the course *CS425: Computer Networks*. The client constructs and sends raw TCP packets (SYN, ACK) and processes incoming packets (SYN-ACK) to simulate the handshake process.

## Features
- Constructs and sends raw TCP packets (SYN, ACK).
- Receives and processes SYN-ACK packets from the server.
- Logs TCP header details for debugging purposes.
- Demonstrates the low-level working of the TCP handshake.

## Prerequisites
- *Root permissions* are required to run the client because raw sockets are used.
- A server must be running locally (on 127.0.0.1) and listening on port 12345.

## Setup and Usage

### Steps to Run
1. Open a terminal in the directory containing the client and server code.
2. Compile the code:
   bash
   make
   
3. Run the server and client as root:
   bash
   sudo ./server
   sudo ./client
   

## Files
- client.cpp    : raw socket client.
- server.cpp    : server file.
- README.txt    : This file.