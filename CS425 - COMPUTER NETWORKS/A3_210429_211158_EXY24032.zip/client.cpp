#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>

// Constants
constexpr int SERVER_PORT = 12345;  // Port number of the server
constexpr int CLIENT_PORT = 54321;  // Port number of the client
constexpr int BUFFER_SIZE = 64000; // Buffer size for receiving packets
constexpr char LOCALHOST[] = "127.0.0.1"; // Localhost IP address

// Utility function to print TCP flags and header information
// This function is used for debugging and logging TCP header details
void printTcpHeader(const struct tcphdr* tcpHeader) {
    std::cout << "[Flags] SYN=" << tcpHeader->syn
              << " ACK=" << tcpHeader->ack
              << " FIN=" << tcpHeader->fin
              << " RST=" << tcpHeader->rst
              << " PSH=" << tcpHeader->psh
              << " SEQ=" << ntohl(tcpHeader->seq)
              << " ACK_NUM=" << ntohl(tcpHeader->ack_seq)
              << " SRC_PORT=" << ntohs(tcpHeader->source)
              << " DST_PORT=" << ntohs(tcpHeader->dest)
              << std::endl;
}

// Constructs an IP header with common fields pre-filled
// This function initializes the IP header with standard values
void constructIpHeader(struct iphdr* ipHeader, in_addr_t destAddr) {
    ipHeader->ihl = 5; // Internet Header Length (5 = 20 bytes)
    ipHeader->version = 4; // IPv4
    ipHeader->tos = 0; // Type of Service
    ipHeader->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr)); // Total length of IP + TCP headers
    ipHeader->id = htons(0xbeef); // Identification field
    ipHeader->frag_off = 0; // No fragmentation
    ipHeader->ttl = 64; // Time to Live
    ipHeader->protocol = IPPROTO_TCP; // Protocol (TCP)
    ipHeader->saddr = inet_addr(LOCALHOST); // Source IP address
    ipHeader->daddr = destAddr; // Destination IP address
}

// Builds and sends a SYN packet to initiate the handshake
// This function sends the first packet in the TCP three-way handshake
void sendSynPacket(int socketFd, const struct sockaddr_in& serverAddr) {
    char packet[sizeof(struct iphdr) + sizeof(struct tcphdr)] = {0}; // Buffer for IP + TCP headers

    // Construct the IP header
    struct iphdr* ipHeader = reinterpret_cast<struct iphdr*>(packet);
    constructIpHeader(ipHeader, serverAddr.sin_addr.s_addr);

    // Construct the TCP header
    struct tcphdr* tcpHeader = reinterpret_cast<struct tcphdr*>(packet + sizeof(struct iphdr));
    tcpHeader->source = htons(CLIENT_PORT); // Source port
    tcpHeader->dest = htons(SERVER_PORT); // Destination port
    tcpHeader->seq = htonl(200); // Sequence number
    tcpHeader->doff = 5; // Data offset (5 = 20 bytes)
    tcpHeader->syn = 1; // SYN flag
    tcpHeader->window = htons(8192); // Window size
    tcpHeader->check = 0; // Checksum (not calculated here)

    // Send the SYN packet
    if (sendto(socketFd, packet, sizeof(packet), 0, reinterpret_cast<const struct sockaddr*>(&serverAddr), sizeof(serverAddr)) < 0) {
        perror("sendto (SYN)"); // Print error if send fails
        exit(EXIT_FAILURE);
    }

    printTcpHeader(tcpHeader); // Log the TCP header
    std::cout << "[*] SYN packet dispatched.\n";
}

// Builds and sends an ACK packet to complete the handshake
// This function sends the third packet in the TCP three-way handshake
void sendAckPacket(int socketFd, const struct sockaddr_in& serverAddr, const struct tcphdr* receivedTcpHeader) {
    char packet[sizeof(struct iphdr) + sizeof(struct tcphdr)] = {0}; // Buffer for IP + TCP headers

    // Construct the IP header
    struct iphdr* ipHeader = reinterpret_cast<struct iphdr*>(packet);
    constructIpHeader(ipHeader, serverAddr.sin_addr.s_addr);
    ipHeader->id = htons(0xabcd); // Identification field

    // Construct the TCP header
    struct tcphdr* tcpHeader = reinterpret_cast<struct tcphdr*>(packet + sizeof(struct iphdr));
    tcpHeader->source = htons(CLIENT_PORT); // Source port
    tcpHeader->dest = htons(SERVER_PORT); // Destination port
    tcpHeader->seq = htonl(600); // Sequence number
    tcpHeader->ack_seq = htonl(ntohl(receivedTcpHeader->seq) + 1); // Acknowledgment number
    tcpHeader->doff = 5; // Data offset
    tcpHeader->ack = 1; // ACK flag
    tcpHeader->window = htons(8192); // Window size
    tcpHeader->check = 0; // Checksum (not calculated here)

    // Send the ACK packet
    if (sendto(socketFd, packet, sizeof(packet), 0, reinterpret_cast<const struct sockaddr*>(&serverAddr), sizeof(serverAddr)) < 0) {
        perror("sendto (ACK)"); // Print error if send fails
        exit(EXIT_FAILURE);
    }

    printTcpHeader(tcpHeader); // Log the TCP header
    std::cout << "[*] ACK packet dispatched.\n";
}

// Receives a SYN-ACK packet and returns a pointer to its TCP header
// This function waits for the second packet in the TCP three-way handshake
const struct tcphdr* waitForSynAck(int socketFd) {
    static char recvBuffer[BUFFER_SIZE]; // Buffer for receiving packets
    struct sockaddr_in sourceAddr {}; // Source address
    socklen_t addrLen = sizeof(sourceAddr);

    while (true) {
        // Receive a packet
        int length = recvfrom(socketFd, recvBuffer, BUFFER_SIZE, 0, reinterpret_cast<struct sockaddr*>(&sourceAddr), &addrLen);
        if (length < 0) {
            perror("recvfrom"); // Print error if receive fails
            continue;
        }

        // Parse the IP and TCP headers
        struct iphdr* ipHeader = reinterpret_cast<struct iphdr*>(recvBuffer);
        struct tcphdr* tcpHeader = reinterpret_cast<struct tcphdr*>(recvBuffer + ipHeader->ihl * 4);

        // Check if the packet is for this client
        if (ntohs(tcpHeader->dest) != CLIENT_PORT) continue;

        // Check if the packet is a SYN-ACK
        if (tcpHeader->syn && tcpHeader->ack && ntohl(tcpHeader->ack_seq) == 201) {
            printTcpHeader(tcpHeader); // Log the TCP header
            std::cout << "[*] Received SYN-ACK from server.\n";
            return tcpHeader; // Return the TCP header
        }
    }
}

// Sets up raw socket and executes the three-way handshake
// This function orchestrates the entire TCP handshake process
void initiateTcpHandshake() {
    // Create a raw socket
    int rawSocket = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (rawSocket < 0) {
        perror("socket"); // Print error if socket creation fails
        exit(EXIT_FAILURE);
    }

    // Enable IP header inclusion
    int includeIpHeader = 1;
    if (setsockopt(rawSocket, IPPROTO_IP, IP_HDRINCL, &includeIpHeader, sizeof(includeIpHeader)) < 0) {
        perror("setsockopt"); // Print error if setting socket option fails
        close(rawSocket);
        exit(EXIT_FAILURE);
    }

    // Configure the server address
    struct sockaddr_in serverAddr {};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, LOCALHOST, &serverAddr.sin_addr);

    // Perform the TCP three-way handshake
    sendSynPacket(rawSocket, serverAddr); // Send SYN
    const struct tcphdr* receivedTcpHeader = waitForSynAck(rawSocket); // Wait for SYN-ACK
    sendAckPacket(rawSocket, serverAddr, receivedTcpHeader); // Send ACK

    std::cout << "[✓] TCP Three-way Handshake completed.\n";
    close(rawSocket); // Close the socket
}

int main() {
    std::cout << "[+] Initiating client-side TCP handshake...\n";
    initiateTcpHandshake(); // Start the handshake process
    return 0;
}