#include <iostream>
#include <fstream>
#include <string>
#include <thread>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX_BUFFER_SIZE 1024
#define PORT 12345

std:: unordered_map <std::string , int>                        clients; // Client username -> socket
std:: unordered_map <std::string , std::string>                users; // Username -> password
std:: unordered_map <std::string , std:: unordered_set <int>>  groups; // Group -> client sockets
std:: unordered_map <int , std::unordered_set<std::string>>    userGroups; // Client socket -> group

std::mutex clientsMutex;  // For safe access to clients map
std::mutex groupsMutex;   // For safe access to groups map
std::mutex serverMutex;   // For safe access to server's output

void sendToClient(int clientSocket, const std::string &message) {
    //Wrapper function to send the message to 'clientSocket'
    send(clientSocket, message.c_str(), message.size(), 0);
}

void serverLog(const std::string &logMessage)
{
    serverMutex.lock();
    std::cout << logMessage << "\n";
    serverMutex.unlock();
}

bool hasPrefix(const std::string& str, const std::string& prefix) {
    return str.find(prefix) == 0;
}

void resetBuffer(char* buffer)
{
    memset(buffer, 0, MAX_BUFFER_SIZE);
}

// Authentication function
bool isUserAuthenticated(const std::string &username,const std::string &password, int clientSocket)
{
    if (users.find(username) == users.end() || users[username] != password) {
        std::string logMessage = "Invalid username or password " + username + password;
        serverLog(logMessage);

        sendToClient(clientSocket, "Authentication failed.");

        close(clientSocket);
        return false;
    }
    return true;
}

// Check if user is already connected
bool isUserAlreadyConnected(int clientSocket, const std::string &username) {
    std::lock_guard<std::mutex> lock(clientsMutex);
    if (clients.find(username) != clients.end()) {
        sendToClient(clientSocket, "Error: User already connected!");
        close(clientSocket);
        return true;
    }
    return false;
}

// Register client to the server
void registerClient(const std:: string &username, int clientSocket)
{
    clientsMutex.lock();
    clients[username]= clientSocket;
    clientsMutex.unlock();
}

// Notify client connected to the server
void notifyClientConnected(int clientSocket, const std:: string &username)
{
    std::string logMessage = username + " connected to the server!";
    serverLog(logMessage);

    std:: string loggingMessage = "Hello " + username + ", Welcome to the server!";
    sendToClient(clientSocket, loggingMessage);
}

// Notify client disconnected from the server
void notifyClientDisconnected(std::string &username, int clientSocket)
{
    std::string logMessage = username + " disconnected from the server";
    serverLog(logMessage);

    close(clientSocket);
}

// Send private message to a client
void sendPrivateMessage(int clientSocket, std::string &recipient, std::string &private_msg,std:: string &username) {
    bool found = false;
    std:: string msg = "[" + username + "]: " + private_msg;

    clientsMutex.lock();
    if(clients.find(recipient) != clients.end()){
        found = true;
    }   
    clientsMutex.unlock();
    if(found){
        sendToClient(clients[recipient], msg);
    }
    else{
        sendToClient(clientSocket, "Error: User not found!");
    }
}

// Handle private message command from client
void handlePrivateMessageCommand(int clientSocket, std::string &username, std::string &message)
{
    size_t space1 = message.find(' ');
    size_t space2 = message.find(' ', space1 + 1);
    if (space1 != std::string::npos && space2 != std::string::npos) {
        std::string recipient = message.substr(space1 + 1, space2 - space1 - 1);
        std::string private_msg = message.substr(space2 + 1);
        sendPrivateMessage(clientSocket, recipient, private_msg, username);
    }
    else{
        sendToClient(clientSocket, "Error: Invalid command!");
    }
}

// Send group message to all clients in the group
void sendGroupMessage(int clientSocket, std::string &group_name, std::string &group_msg) {
    std::string msg = "[Group " + group_name + "]: " + group_msg;
    groupsMutex.lock();
    if (groups.find(group_name) != groups.end()) {
        if(groups[group_name].find(clientSocket)!= groups[group_name].end()){
            for (auto& client : groups[group_name]) {
                sendToClient(client, msg);
            }
        }
        else{
            sendToClient(clientSocket, "Error: You have not joined the group yet!");
        }
    } else {
        std::string msg = "Error: Group " + group_name + " does not exist!";
        sendToClient(clientSocket, msg);
    }
    groupsMutex.unlock();
}

// Handle group message command from client 
void handleGroupMessageCommand(int clientSocket, std::string &message)
{
    size_t space1 = message.find(' ');
    size_t space2 = message.find(' ', space1 + 1);
    if (space1 != std::string::npos && space2 != std::string::npos) {
        std::string group_name = message.substr(space1 + 1, space2 - space1 - 1);
        std::string group_msg = message.substr(space2 + 1);
        sendGroupMessage(clientSocket, group_name, group_msg);
    }
    else{
        sendToClient(clientSocket, "Error: Invalid command!");
    }
}

// Send broadcast message to all clients
void sendBroadcastMessage(int clientSocket, std::string &broadcast_msg, std::string &username) {
    std:: string msg = "[Broadcast from " + username + "]: " + broadcast_msg;
    clientsMutex.lock();
    for (auto& [user, client] : clients) {
        if (client != clientSocket) {
            sendToClient(client, msg);
        }
    }
    clientsMutex.unlock();
}

// Handle broadcast command from client 
void handleBroadcastCommand(int clientSocket, std::string &username, std::string &message)
{
    std::string broadcast_msg = message.substr(11);
    if(broadcast_msg.size()>0){
        sendBroadcastMessage(clientSocket, broadcast_msg, username);
    }
    else{ 
        sendToClient(clientSocket, "Error: Invalid command!");
    }
}

// Create group and add client to the group
void createGroup(int clientSocket, std::string &group_name) {
    std:: string msg = "Group " + group_name + " created";
    groupsMutex.lock();
    if (groups.find(group_name) == groups.end()) {
        groups[group_name] = std::unordered_set<int>();
        groups[group_name].insert(clientSocket);
        userGroups[clientSocket].insert(group_name);
        sendToClient(clientSocket, msg);
    } else {
        std::string err = "Error: Group " + group_name + " already exists!";
        sendToClient(clientSocket, err);
    }
    groupsMutex.unlock();
}

// Handle create group command from client 
void handleCreateGroupCommand(int clientSocket, std::string &message)
{
    size_t space1 = message.find(' ');
    if (space1 != std::string::npos) {
        std::string group_name = message.substr(space1 + 1);
        createGroup(clientSocket, group_name);
    }
    else{
        sendToClient(clientSocket, "Error: Invalid command!");
    }
}

// Add client to the group 
void joinGroup(int clientSocket, std::string &group_name) {
    std::string msg = "Joined group " + group_name;
    groupsMutex.lock();
    if (groups.find(group_name) != groups.end()) {
        if(groups[group_name].find(clientSocket)!= groups[group_name].end()){
            sendToClient(clientSocket, "Error: You have already joined the group!");
            groupsMutex.unlock();
            return;
        }
        groups[group_name].insert(clientSocket);
        userGroups[clientSocket].insert(group_name);
        sendToClient(clientSocket, msg);
    } else {
        std::string msg = "Error: Group " + group_name + " does not exist!";
        sendToClient(clientSocket, msg);
    }
    groupsMutex.unlock();
}

// Handle join group command from client
void handleJoinGroupCommand(int clientSocket, std::string &message)
{
    size_t space1 = message.find(' ');
    if (space1 != std::string::npos) {
        std::string group_name = message.substr(space1 + 1);
        joinGroup(clientSocket, group_name);
    }
    else{
        sendToClient(clientSocket, "Error: Invalid command!");
    }   
}

// Remove client from the group 
void leaveGroup(int clientSocket, std::string &group_name) {
    std::string msg = "You left the group " + group_name;
    groupsMutex.lock();
    if (groups.find(group_name) != groups.end()) {
        if(groups[group_name].find(clientSocket)== groups[group_name].end()){
            sendToClient(clientSocket, "Error: You have not joined the group yet!");
            groupsMutex.unlock();
            return;
        }
        groups[group_name].erase(clientSocket);
        userGroups[clientSocket].erase(group_name);
        sendToClient(clientSocket, msg);
        if(groups[group_name].size() == 0)
        {
            groups.erase(group_name);
        }
    } else {
        std::string msg = "Error: Group " + group_name + " does not exist!";
        sendToClient(clientSocket, msg);
    }
    groupsMutex.unlock();
}

// Handle leave group command from client
void handleLeaveGroupCommand(int clientSocket, std::string &message)
{
    size_t space1 = message.find(' ');
    if (space1 != std::string::npos) {
        std::string group_name = message.substr(space1 + 1);
        leaveGroup(clientSocket, group_name);
    }
    else{
        sendToClient(clientSocket, "Error: Invalid command!");
    }
}

// Remove client from server
void removeClientFromServer(std::string &username, int clientSocket)
{
    clientsMutex.lock();
    clients.erase(username);
    clientsMutex.unlock();

    // Remove client from groups
    groupsMutex.lock();
    if (userGroups.find(clientSocket) != userGroups.end()) {
        for (auto& group : userGroups[clientSocket]) {
            groups[group].erase(clientSocket);
            if(groups[group].size()==0) {
                groups.erase(group);
            }
        }
        userGroups.erase(clientSocket);
    }
    groupsMutex.unlock();
}

// Process client requests in a separate thread
void processClientRequests(int clientSocket) {
    char buffer[MAX_BUFFER_SIZE];
    int bytesRead;

    // Authenticate user with username and password
    std::string username, password;
    sendToClient(clientSocket, "Enter username: ");
    bytesRead = recv(clientSocket, buffer, MAX_BUFFER_SIZE, 0);

    if (bytesRead <= 0) {
        close(clientSocket);
        return;
    }

    username = buffer;
    resetBuffer(buffer);

    sendToClient(clientSocket, "Enter password: ");
    bytesRead = recv(clientSocket, buffer, MAX_BUFFER_SIZE, 0);

    if (bytesRead <= 0) {
        close(clientSocket);
        return;
    }

    password = buffer;
    resetBuffer(buffer);

    bool PasswordCheck = isUserAuthenticated(username, password, clientSocket);
    if(PasswordCheck == false) return;

    // Check if user is already connected to the server
    if (isUserAlreadyConnected(clientSocket, username)) {
        return;
    }

    registerClient(username, clientSocket);

    // log the connection in both client and server
    notifyClientConnected(clientSocket, username);

    while (true) {
        // Receive data from client
        bytesRead = recv(clientSocket, buffer, MAX_BUFFER_SIZE, 0);
        if (bytesRead <= 0) {
            break;
        }
        // Process received data
        std::string message = buffer;
        resetBuffer(buffer);

        // Log the message received from the client
        std::string logMessage = "Received from " + username + ": " + message;
        serverLog(logMessage);

        // Process client command 
        if (hasPrefix(message,"/msg")) 
        {
            handlePrivateMessageCommand(clientSocket, username, message);
        } 
        else if (hasPrefix(message,"/group_msg")) 
        {
            handleGroupMessageCommand(clientSocket, message);
        } 
        else if (hasPrefix(message,"/broadcast ")) 
        {
            handleBroadcastCommand(clientSocket, username, message);
        } 
        else if (hasPrefix(message,"/create_group")) 
        {
            handleCreateGroupCommand(clientSocket, message);
        } 
        else if (hasPrefix(message,"/join_group"))
        {
            handleJoinGroupCommand(clientSocket, message);
        } 
        else if (hasPrefix(message,"/leave_group")) 
        {
            handleLeaveGroupCommand(clientSocket, message);
        } 
        else 
        { // Invalid command
            sendToClient(clientSocket, "Error: Invalid command!");
        }
    }
    removeClientFromServer(username, clientSocket);

    notifyClientDisconnected(username, clientSocket);
}

// Load user database from 'users.txt' file
bool loadUserDatabase(const std::string &fileName = "users.txt")
{
    std::ifstream file(fileName);
    std::string line, username, password;

    if(file.is_open()){
        while(getline(file, line)){
            username = line.substr(0, line.find(':'));
            password = line.substr(line.find(':')+1);
            users[username] = password;
        }
        file.close();
    }
    else return false;

    return true;
}

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddress, clientAddress;
    socklen_t clientAddressLength = sizeof(clientAddress);

    // Create server socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        serverLog("Error: Failed to create server socket");
        return 1;
    }
    
    // Set server address
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(PORT);

    // Bind server socket to the specified address and port
    if (bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == -1) {
        serverLog("Error: Failed to bind server socket");
        return 1;
    }

    // Start listening for client connections
    if (listen(serverSocket, 5) == -1) {
        serverLog("Error: Failed to listen for client connections");
        return 1;
    }

    serverLog( "Hurray! Server started.");

    bool usernameCheck = loadUserDatabase("users.txt");

    if(usernameCheck == false){
        serverLog("Error: Failed to open users file");
        return 1;
    }

    while (true) {
        // Accept client connection
        clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddress, &clientAddressLength);
        if (clientSocket == -1) {
            serverLog("Error: Failed to accept client connection");
            continue;
        }

        // Handle client in a separate thread
        std::thread clientThread(processClientRequests, clientSocket);
        clientThread.detach();
    }

    // Close server socket
    close(serverSocket);

    return 0;
}