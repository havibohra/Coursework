# Chat Server with Groups and Private Messages

## Overview
This is a multi-threaded chat server developed for CS425: Computer Networks Assignment 1. The server supports private messaging, group communication, and user authentication using TCP sockets.

## Features
### Implemented Features:
- Multi-threaded TCP server supporting multiple clients.
- User authentication using a `users.txt` file.
- Private messaging using `/msg <username> <message>`.
- Broadcast messaging using `/broadcast <message>`.
- Group management:
  - Create groups using `/create_group <group_name>`.
  - Join groups using `/join_group <group_name>`.
  - Leave groups using `/leave_group <group_name>`.
  - Group messaging using `/group_msg <group_name> <message>`.

### Not Implemented Features:
- User registration via the client (users must be pre-added to `users.txt`).
- Persistent storage for chat messages.
- Admin features (e.g., group moderation, kicking users).

## Design Decisions
- **Multi-threading:** Each client connection is handled in a separate thread using `std::thread`, allowing concurrent connections.
- **Synchronization:** `std::mutex` ensures thread safety for shared resources like `clients`, `groups`, and `userGroups`.
- **Authentication:** Username and password pairs are loaded from `users.txt` at server startup.
- **Communication Protocol:** Simple text-based commands parsed on the server side.
- **Disconnected user** is removed from joined groups and can't receive message from any active user
- **Multiple login** of same user isn't allowed
- **Group Message:** All group members including sender will receive the message. (Group members can't see the sender username, as specified by syntax)
- **Broadcast Message:** message will be sent to every active user except sender itself. (Recipients can see the sender username, as specified by syntax)
- **Zero Membered Group:** (happens when all group members leave) such a group will be deleted as soon as last member leaves, and hence a new group with the name can be created afterwards

## Implementation
### High-Level Idea of Important Functions:
- `processClientRequests(int clientSocket)`: Handles client authentication and command processing.
- `sendToClient(int clientSocket, const std::string &message)`: Sends a message to a client.
- `handlePrivateMessageCommand(int clientSocket, std::string &username, std::string &message)`: Parses and forwards private messages.
- `handleGroupMessageCommand(int clientSocket, std::string &message)`: Processes group messages.
- `handleBroadcastCommand(int clientSocket, std::string &username, std::string &message)`: Handles broadcast messages.
- `createGroup(int clientSocket, std::string &group_name)`: Handles group creation.
- `joinGroup(int clientSocket, std::string &group_name)`: Handles group joining.
- `leaveGroup(int clientSocket, std::string &group_name)`: Handles leaving a group.

### Code Flow (Simplified):
![codeflow image](codeflow.jpeg)
1. Server starts, loads users from `users.txt`.
2. Server listens on port `12345`.
3. Clients connect and authenticate.
4. Server spawns a thread for each client.
5. Clients send commands, and the server processes them.
6. Clients disconnect, and the server removes them from active lists.

## Functionality Testing
- **Correctness Testing:** Verified commands (`/msg`, `/broadcast`, `/group_msg`, etc.) work as expected both manually and by unit-testing.
  
- **Edge Case Testing:**
  - Invalid usernames/passwords.
  - Sending messages to offline users.
  - Joining non-existent groups.
  - Creating existing group.
  - Attempting to leave a group before joining.
  - Messaging to un-joined group.
  - Joining a joined group.

## Stress-Testing
Simulated multiple concurrent connections using different client threads. Each test was run 100 times for different numbers of clients (5, 10, 25, 50, 100, 250). The results show the number of times all clients passed without any timeout issues out of 100 runs for each number of clients.

| No. of Clients | Successful Runs (out of 100) |
| -------------- | ---------------------------- |
| 5              | 100                          |
| 10             | 100                          |
| 25             | 96                           |
| 50             | 83                           |
| 100            | 59                           |
| 250            | 5                            |

### Observations
- The server handled smaller numbers of clients (5, 10 and 25) with high success rates.
- As the number of clients increased, the success rate decreased, indicating potential bottlenecks or resource limitations.
- The stress-testing helped identify areas for optimization, particularly in handling a large number of concurrent connections.

### Conclusion
The stress-testing provided valuable insights into the server's performance under different loads. The results will guide further optimizations to improve scalability and reliability.

## Server Restrictions
- Maximum concurrent connections: Refer stress-testing
- Maximum groups: No explicit limit, but restricted by available memory.
- Maximum members per group: No explicit limit, but restricted by available memory.
- Maximum message size: `1024` bytes (defined by `MAX_BUFFER_SIZE`).

## Challenges Faced
- **Thread synchronization:** Used `std::mutex` to avoid race conditions.
- **Socket handling:** Ensured proper closure of sockets on client disconnection.
- **Command parsing:** Implemented efficient string parsing for different commands.
- **Stress Testing** Faced timeout issues while stress-testing 

## Contribution of Each Member
| Name             | Contribution (%) | Responsibilities                                                 |
| ---------------- | ---------------- | ---------------------------------------------------------------- |
| Havi Bohra  (210429)     | 33%              | Implemented authentication, private messaging, Stress-Testing    |
| Keval Vekariya  (211158) | 34%              | Implemented group messaging, server architecture, modularisation |
| Sunandini Bansal (EXY 24032)| 33%              | Functions testing, debugging, documentation                      |

## Sources Referred
- Beej’s Guide to Network Programming
- C++ reference documentation
- Linux socket programming tutorials

## Declaration
We declare that this assignment is our original work and does not involve plagiarism.

## Feedback
- The assignment provided great hands-on experience with socket programming and multi-threading.
- Suggestion: Add more real-world constraints like rate limiting and persistence.

---
### Instructions to Compile and Run
- Put the server_grp.cpp file in your repository,
- Ensure your client_grp.cpp and users.txt are present in same directory and listens server on port `12345`
1. Compile the server and client:
   ```bash
   make
   ```
2. Run the server:
   ```bash
   ./server_grp
   ```
3. Clients can connect using the provided client program in the repository.
   ```bash
   ./client_grp
   ```

