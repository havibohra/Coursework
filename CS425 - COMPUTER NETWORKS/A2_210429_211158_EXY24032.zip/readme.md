# DNS Resolver

## Overview

This script (`dnsresolver.py`) implements a DNS resolver with both iterative and recursive query resolution methods. It uses the `dnspython` library to send DNS queries and resolve domain names.

## Requirements

Before running the script, ensure you have Python installed (version 3.x recommended) and install the required dependency:


```bash
pip install dnspython
```

## Usage

The script supports two modes:

1. **Iterative DNS resolution**: Queries root servers and traverses down the DNS hierarchy.
2. **Recursive DNS resolution**: Uses system-configured DNS resolvers to fetch results.

### Running the Script

Run the script with the following command:

```bash
python3 dnsresolver.py <mode> <domain>
```

Where:

- `<mode>` can be either `iterative` or `recursive`.
- `<domain>` is the domain name you want to resolve.

### Examples

#### Iterative DNS Resolution

```bash
python3 dnsresolver.py iterative example.com
```

#### Recursive DNS Resolution

```bash
python3 dnsresolver.py recursive example.com
```

## Explanation of the Code

- The script first defines a set of **root DNS servers** as the starting point.
- `send_dns_query(server, domain)`: Sends a DNS query to the given server.
- `extract_next_nameservers(response)`: Extracts the next authoritative nameservers from a DNS response.
- `iterative_dns_lookup(domain)`: Implements the iterative DNS lookup process.
- `recursive_dns_lookup(domain)`: Uses the system resolver to perform recursive resolution.
- The script accepts command-line arguments and determines which resolution mode to execute.

## Error Handling

- If the script encounters a timeout or resolution failure, it prints an appropriate error message.
- The script handles invalid inputs and provides a usage guide when incorrect arguments are passed.

## Execution Time

At the end of execution, the script prints the time taken to resolve the domain.

